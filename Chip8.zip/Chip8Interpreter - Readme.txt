Chip 8 Interpreter created by Karol Firmanty.
http://randomnoise.cba.pl/chip8.html